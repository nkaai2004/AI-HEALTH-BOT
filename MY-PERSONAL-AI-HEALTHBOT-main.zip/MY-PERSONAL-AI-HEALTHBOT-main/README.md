# MY-PERSONAL-AI-HEALTHBOT
This is my own project i decided to do this is after a group work with my colleagues so i made my own for my own understanding
User Guide
Welcome to EVE, your personal health and wellness assistant! EVE is designed to help you with health-related questions and provide useful advice.

Getting Started
To begin interacting with EVE:
1. Visit the chat interface at [your chatbot URL] (e.g.http://127.0.0.1:5001/).
2. Type your message in the input box and click the "Send" button.

Basic Commands;
- Asking Questions: Type any health-related question directly to get advice or information.

Special Features
EVE can handle various types of interactions;
- Greeting: EVE responds to greetings like "hey".

Additional Functions
- Clear Chat History: Click the 'Clear' button to erase the chat history and start fresh.

Example Interactions
- YOU: "Hey"
  - EVE: "Hi, I'm EVE, your AI health expert. You're in a safe space to ask anything or express any concerns you might have.’’

- YOU: "What are some tips for staying healthy?"
  - EVE: [Provides health tips from knowledge base]

Troubleshooting
If EVE doesn't understand your query or if you encounter any issues:
- Check your spelling and phrasing.

Enjoy Your Chat!
Feel free to explore EVE's capabilities and ask any health-related questions you have. Have a great conversation!

- Version: 1.0

For any feedback or suggestions;

maslawayne@gmail.com

Thank you for using EVE!

 
